import { Component } from '@angular/core';

@Component({
  selector:'app-login',
  templateUrl:'app.component.html'
})

export class MyComponent {

}

