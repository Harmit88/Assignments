export class Admin{
    constructor(
       public Name:String,
       public Email:String,
       public cellnumber:number

    ){}
}

export class user{

    constructor(
        public Username:string
    ){}
}