import { Component } from '@angular/core';



@Component({
    selector:'date-app',
     templateUrl:'date.component.html'
})
export class dateComponent{

    UserDate="";
   
}