export interface Ihome{
    name:string,
    author:String,
    price:number,
    release_date:string
}