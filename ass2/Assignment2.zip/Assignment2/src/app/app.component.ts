import { Component } from '@angular/core';
//import { User } from './login.model';


@Component({
 selector:'my-app',
 templateUrl:'app.component.html'
})

export class AppComponent{
 //data = new User('','');
// display(value:String ):void{
  
 //  }
 }
