export interface Iuser{
    id:number,
  Name:string,
  Email:string,
  Contact:string,
  Role:String
}